KIISFM Plugin for Kodi
-------------------------------------------

KIIS-FM LA's #1 Hit Music Station

Setup/Installation: 
The plugin should be installed through the official Kodi addon repository.

