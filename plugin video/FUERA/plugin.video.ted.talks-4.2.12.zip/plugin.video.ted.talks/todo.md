+ youtube?
+ rate limiting in actual addon
