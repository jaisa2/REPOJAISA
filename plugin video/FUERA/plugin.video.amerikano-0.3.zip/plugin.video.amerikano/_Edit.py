import xbmcaddon

MainBase = 'https://pastebin.com/raw/6Db4UPEa'
addon = xbmcaddon.Addon('plugin.video.amerikano0.3')