import xbmcaddon

MainBase = 'https://goo.gl/CP9L2j'
addon = xbmcaddon.Addon('plugin.video.Totalshow')