# plugin.video.tv3.cat
Kodi addon TV3cat. 
Entertainment, news, sports, documentaries, etc from catalan television www.tv3.cat

Complement per Kodi - XBMC.  
Tota la programació de TV3 a la carta. Llistes dels programes Més vistos, Destacats, No t'ho perdis, etc.



