# SportsDevil_JX
This is an unofficial SportsDevil fork by JairoX. It is mainly based on Hubbab3's version but includes some additional sites. I try to provide updates and fixes as needed, though I only check those sites I watch myself.

For information on current development and maintenance status, pls check the tvaddons forum.
