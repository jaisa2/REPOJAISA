# -*- coding: utf-8 -*-
#------------------------------------------------------------
# Contenido para niños de YouTube by j.ruiz
#------------------------------------------------------------
# License: GPL (http://www.gnu.org/licenses/gpl-3.0.html)
# Based on code from youtube addon
#
# Author: j.ruiz
#------------------------------------------------------------

import os
import sys
import plugintools
import xbmc,xbmcaddon
from addon.common.addon import Addon

addonID = 'plugin.video.mundoinfantil'
addon = Addon(addonID, sys.argv)
local = xbmcaddon.Addon(id=addonID)
icon = local.getAddonInfo('icon')

YOUTUBE_CHANNEL_ID_1 = ""
YOUTUBE_CHANNEL_ID_2 = "UCWP0f4wHDHebkAlYGxYZ22Q"
YOUTUBE_CHANNEL_ID_3 = "atiempopreescolar"
YOUTUBE_CHANNEL_ID_4 = "UCVIXxMQ51drJmg9Hj-tXAfg"
YOUTUBE_CHANNEL_ID_5 = "UCQTGHhyi9iURgMaJk4mUqpQ"
YOUTUBE_CHANNEL_ID_6 = "PLjr_J_DQd6zccQTlLNoaWJjdOIbMNgQdM"
YOUTUBE_CHANNEL_ID_7 = "LouieEspanol"
YOUTUBE_CHANNEL_ID_8 = "UCeTdhZLFZEfpHgJ-GAEV-WQ"
YOUTUBE_CHANNEL_ID_9 = "UC-jeD_PS_vuvCIJi_4igm6Q"
YOUTUBE_CHANNEL_ID_10 = "babytvspanish"
YOUTUBE_CHANNEL_ID_11 = "PLjr_J_DQd6zdNkGi-0hpOaraU6FJfsxoU"
YOUTUBE_CHANNEL_ID_12 = "UC4C2vqGpQU04kqh-Gs7mrAg" 
YOUTUBE_CHANNEL_ID_13 = "UCyCATOPgXCOl-0jvaIk5xvQ"
YOUTUBE_CHANNEL_ID_14 = "PLjr_J_DQd6zc9JAkzb-ot1SchpoXXmPwR"
YOUTUBE_CHANNEL_ID_15 = "BoomRedsSpa"
YOUTUBE_CHANNEL_ID_16 = "UCYueUut3fm27z-J35d6wAXg"
YOUTUBE_CHANNEL_ID_17 = "UCCzR0RTeFKJr-kcwADUlSnw"
YOUTUBE_CHANNEL_ID_18 = "PLjr_J_DQd6zfW55_I6bL8amafzLSlzVJI"
YOUTUBE_CHANNEL_ID_19 = "cahoficial"
YOUTUBE_CHANNEL_ID_20 = "PLjr_J_DQd6zcfbJkT9IcfqzgMVXvZQwqU"
YOUTUBE_CHANNEL_ID_21 = "chavoanimadoable"
YOUTUBE_CHANNEL_ID_22 = "UCk2wzETSoKdY2TVW01NRreQ"
YOUTUBE_CHANNEL_ID_23 = "UCBbsyG0o_cWlyY46ZRSdYJg"
YOUTUBE_CHANNEL_ID_24 = "PLjr_J_DQd6zexINy2lCWCG-LEH2OWo-4m"
YOUTUBE_CHANNEL_ID_25 = "PLjr_J_DQd6zemlue2Pn8ZP2jNDOot5UNz"
YOUTUBE_CHANNEL_ID_26 = "UCjgRtV0zjOfsCP0_i3DjA8A"
YOUTUBE_CHANNEL_ID_27 = "UC3xdYJcb7ny8Weoo53vS9LA"
YOUTUBE_CHANNEL_ID_28 = "UCrvbK8-17ErqbAxVCjQUdtA"
YOUTUBE_CHANNEL_ID_29 = "UCNTl__yGTRH7usCFazeXheQ"
YOUTUBE_CHANNEL_ID_30 = "UCggQhf35fbvZOosqcKm2AGA"
YOUTUBE_CHANNEL_ID_31 = "UCsm77kEHBDEPgD4Ir3jSRYg"
YOUTUBE_CHANNEL_ID_32 = "PLjr_J_DQd6zfQEFSL3yn4Lcg5tXuR3mOC"
YOUTUBE_CHANNEL_ID_33 = "UCY0TNnnoZMapIQ3cXv1M1rg"
YOUTUBE_CHANNEL_ID_34 = "UChlTeveFUK6bvHrmCb8J99w"
YOUTUBE_CHANNEL_ID_35 = "UC6hKFu_Di-pASp0W__7ZKUw"
YOUTUBE_CHANNEL_ID_36 = "GallinaPintadita"
YOUTUBE_CHANNEL_ID_37 = "UCGkVdu_EVrqqxQ7OnLFK8RQ"
YOUTUBE_CHANNEL_ID_38 = "MusicaDeNinos"
YOUTUBE_CHANNEL_ID_39 = "HooplaKidzEspanol"
YOUTUBE_CHANNEL_ID_40 = "UCLTIbNhj8PsPbGoDDfBfTrw"
YOUTUBE_CHANNEL_ID_41 = "UCWNm9s6fZeivd1SSI9PmS9A"
YOUTUBE_CHANNEL_ID_42 = "UCBlslL5pqbe8EwI1Edx__Fw"
YOUTUBE_CHANNEL_ID_43 = "UC6o1UyB8uQlHKBJuUwhvlVA"
YOUTUBE_CHANNEL_ID_44 = "cancionesdelzoo"
YOUTUBE_CHANNEL_ID_45 = "PLjr_J_DQd6zderf9oitse8IFP12YbCUOq"
YOUTUBE_CHANNEL_ID_46 = "cancionesdelagranja"
YOUTUBE_CHANNEL_ID_47 = "PLWYQuS6aEMRDcHza5LQjPbRkrwu2qt6DT"
YOUTUBE_CHANNEL_ID_48 = "UCtdTidjV6cenXSueJiHBxlw"
YOUTUBE_CHANNEL_ID_49 = "PLjr_J_DQd6zejxzQnZFJoZWwHcJ-xOV1L"
YOUTUBE_CHANNEL_ID_50 = "lunacreciente"
YOUTUBE_CHANNEL_ID_51 = "PLjr_J_DQd6zdPZSNo6lu4swFgnUZWuWcG"
YOUTUBE_CHANNEL_ID_52 = "UCUKjpcXaE3jvnjgVpF86OLg"
YOUTUBE_CHANNEL_ID_53 = "UCdFAbctdV4NL_Vgy6MxNCKQ"
YOUTUBE_CHANNEL_ID_54 = "siniestromu"
YOUTUBE_CHANNEL_ID_55 = "UCgsNuUwnSLzxBNDD2X2_Hgw"
YOUTUBE_CHANNEL_ID_56 = "UC1vKPJSQ9VGMoPS1FP01NUw"
YOUTUBE_CHANNEL_ID_57 = "UCXeWf1D51KJQJEYemqsOdPQ"
YOUTUBE_CHANNEL_ID_58 = "UCwnmHLNwY0WRLFqnZMMIIFQ"
YOUTUBE_CHANNEL_ID_59 = "UCX0pqVKo23G_4XpkACv2tDA"
YOUTUBE_CHANNEL_ID_60 = "PicaPicaVEVO"
YOUTUBE_CHANNEL_ID_61 = "PICCOLOMONDOpr" 
YOUTUBE_CHANNEL_ID_62 = "UCrYwqJZ-AnvnyF8vRndgvnA"
YOUTUBE_CHANNEL_ID_63 = "PLjr_J_DQd6zdzqmNiIiTjVNRAlRMTWg67"
YOUTUBE_CHANNEL_ID_64 = "PLkJqc6IY1H2aKpSCjHZ_yNmgOI9fSnUwt"
YOUTUBE_CHANNEL_ID_65 = "elcanaldePlimPlim"
YOUTUBE_CHANNEL_ID_66 = "UCs156bCTwCkfDypjJ8xxh5Q" 
YOUTUBE_CHANNEL_ID_67 = "PLjr_J_DQd6zcLG5c_OX6GWwqo88aiz821"
YOUTUBE_CHANNEL_ID_68 = "UCdXeAVe2TzFG_u-Fz6Tixfg"
YOUTUBE_CHANNEL_ID_69 = "UCRSxDzPxGwQmvmaovwhermQ"
YOUTUBE_CHANNEL_ID_70 = "RositaFresitaOficial"
YOUTUBE_CHANNEL_ID_71 = "UCI9n4mqNa7206a6oPhxJnAw"
YOUTUBE_CHANNEL_ID_72 = "plazasesamo"
YOUTUBE_CHANNEL_ID_73 = "UCc_alYmt_LTSb5oOjF8Stjw"
YOUTUBE_CHANNEL_ID_74 = "UCOnprKBB5g8HgTAr0CBCzzg"
YOUTUBE_CHANNEL_ID_75 = "TiempodeSol" 
YOUTUBE_CHANNEL_ID_76 = "TioSpanish"
YOUTUBE_CHANNEL_ID_77 = "traposotv"
YOUTUBE_CHANNEL_ID_78 = "PLjr_J_DQd6zdPzAbh_fnaLpjepDOkYIZb"
YOUTUBE_CHANNEL_ID_79 = "todoesrosie"
YOUTUBE_CHANNEL_ID_80 = "UCC9R-cxQeOpPhq2lAru0V8w"
YOUTUBE_CHANNEL_ID_81 = "PLjr_J_DQd6ze4cdGvTklqXDutNhSA5uio"
YOUTUBE_CHANNEL_ID_82 = "TutituSpanish"
YOUTUBE_CHANNEL_ID_83 = "tuyycantando"
YOUTUBE_CHANNEL_ID_84 = "PLVBlddRXYB8c_nPCGR6zJlpo_rBD9Oxms"
YOUTUBE_CHANNEL_ID_85 = "dhxjuniortvspain"
YOUTUBE_CHANNEL_ID_86 = "PLjr_J_DQd6zf79x_e-ZMtU5XF0A7fU4qT"
YOUTUBE_CHANNEL_ID_87 = "UC9qYmozfImX8ft03Gp5jeRQ"
YOUTUBE_CHANNEL_ID_88 = "checkgate"
YOUTUBE_CHANNEL_ID_89 = "UC_qs3c0ehDvZkbiEbOj6Drg"
YOUTUBE_CHANNEL_ID_90 = "AllBabiesChannel"
YOUTUBE_CHANNEL_ID_91 = "UCB_2_OiPFh6FdUvp50_maug"
YOUTUBE_CHANNEL_ID_92 = "AngelinaBallerina"
YOUTUBE_CHANNEL_ID_93 = "UClaL-7nRvyrv2eL_EoZNMdw"
YOUTUBE_CHANNEL_ID_94 = "PLV7TQ9bBUnPMl6lAQlUxEAq-zh10XXRCH"
YOUTUBE_CHANNEL_ID_95 = "UCLgUufCC7Q-skizKrVmKDyg" 
YOUTUBE_CHANNEL_ID_96 = "BabyTVChannel"
YOUTUBE_CHANNEL_ID_97 = "barbie"
YOUTUBE_CHANNEL_ID_98 = "UC9qYmozfImX8ft03Gp5jeRQ"
YOUTUBE_CHANNEL_ID_99 = "PL7p22HOpmUgW9d_8hcESmYJMuEFxowJia"
YOUTUBE_CHANNEL_ID_100 = "badanamu01"
YOUTUBE_CHANNEL_ID_101 = "bananasinpyjamas"
YOUTUBE_CHANNEL_ID_102 = "TVBinkie"
YOUTUBE_CHANNEL_ID_103 = "PLjr_J_DQd6zcXmVf5-5Eenz6N6tNYw7Aq"
YOUTUBE_CHANNEL_ID_104 = "UC-GsApAlbiTDILDnxP1O7RA"
YOUTUBE_CHANNEL_ID_105 = "bobthebuilderchannel"
YOUTUBE_CHANNEL_ID_106 = "KedooTV"
YOUTUBE_CHANNEL_ID_107 = "wearebusybeavers"
YOUTUBE_CHANNEL_ID_108 = "UCFZvNZasiRd8HbYMEOi19VQ"
YOUTUBE_CHANNEL_ID_109 = "UCwOS0K6uKOqoAWU7MUEtxaQ"
YOUTUBE_CHANNEL_ID_110 = "ChloesClosetTVShow" 
YOUTUBE_CHANNEL_ID_111 = "TheChuChuTV"
YOUTUBE_CHANNEL_ID_112 = "UCDSB6AcJzMS5HZNERwGHV-g"
YOUTUBE_CHANNEL_ID_113 = "UCR5dkvkHTEQeCKeIVM-cdkg"
YOUTUBE_CHANNEL_ID_114 = "PLCI_BIMJR-XFv8VwHFKt1R3LCPMKqbraf"
YOUTUBE_CHANNEL_ID_115 = "UC9e_51yOZpZSYVxKurSj_jw"
YOUTUBE_CHANNEL_ID_116 = "everythingsrosietv"
YOUTUBE_CHANNEL_ID_117 = "UCu9MYfF0vosVcK38oNnnJxw"
YOUTUBE_CHANNEL_ID_118 = "UC0j36_NCIX_eSc1nXfNGXVQ"
YOUTUBE_CHANNEL_ID_119 = "firemansamchannel"
YOUTUBE_CHANNEL_ID_120 = "littlepeople"
YOUTUBE_CHANNEL_ID_121 = "UCd9HyZnIct6G_-WXdl-CPyw"
YOUTUBE_CHANNEL_ID_122 = "UCW75F3k82ovrT0woSEyzZ8w"
YOUTUBE_CHANNEL_ID_123 = "UC8eJxPzmvTb12v7LlZUJcLQ"
YOUTUBE_CHANNEL_ID_124 = "PLv042z7GzQ6vtc_xHnKTJWksgr_8Qv-cY"
YOUTUBE_CHANNEL_ID_125 = "UCQIZNADyAdMEWhjM8cq7ROw"
YOUTUBE_CHANNEL_ID_126 = "UCdkQJ6GDi1sLVhCkz4qiMaQ"
YOUTUBE_CHANNEL_ID_127 = "PLhWqOkS7-6p9eTMB8kCkQ38qQ_sUS25zE"
YOUTUBE_CHANNEL_ID_128 = "UCnlGLvCaRYCyZXA7Y0KuKZA"
YOUTUBE_CHANNEL_ID_129 = "Kikoriki"
YOUTUBE_CHANNEL_ID_130 = "PLxrv_vTPuZ6S6r8nmbmy7lCiLHUWgYs1f"
YOUTUBE_CHANNEL_ID_131 = "lazytown"
YOUTUBE_CHANNEL_ID_132 = "UCfJNFWEwKbXD_ydIXhZRj3A"
YOUTUBE_CHANNEL_ID_133 = "PLjr_J_DQd6zfmuNqKwIoMWmnpwXsSNkNc"
YOUTUBE_CHANNEL_ID_134 = "LittleBabyBum"
YOUTUBE_CHANNEL_ID_135 = "UCydekQV_GkprQFYMdgc8e6A"
YOUTUBE_CHANNEL_ID_136 = "PLjr_J_DQd6zfYu1oFWEAE04ZYLvcbxbqg"
YOUTUBE_CHANNEL_ID_137 = "UCvEIOXJOFmUgbh-g3Ep1tmQ"
YOUTUBE_CHANNEL_ID_138 = "LooLooKids"
YOUTUBE_CHANNEL_ID_139 = "MashaBearEN"
YOUTUBE_CHANNEL_ID_140 = "UCmElsfgN0WY4ycwKHKWbTyg"
YOUTUBE_CHANNEL_ID_141 = "UCO0vPDAqN7BTK9kNAeP3sKw"
YOUTUBE_CHANNEL_ID_142 = "UCXLLQkbYE-G9jYrra7R4Qsw"
YOUTUBE_CHANNEL_ID_143 = "UCW4jDLxKLfnOrEMIvzIZUsw"
YOUTUBE_CHANNEL_ID_144 = "UCKe-7-MbrHXAUB3hYTa6pkw"
YOUTUBE_CHANNEL_ID_145 = "Peekaboo"
YOUTUBE_CHANNEL_ID_146 = "theofficialpeppa"
YOUTUBE_CHANNEL_ID_147 = "UCngkVoq8aayyK6qX9JJitRg"
YOUTUBE_CHANNEL_ID_148 = "SmartBooksMedia"
YOUTUBE_CHANNEL_ID_149 = "UCY2jUnU118sVkdj2xafiJ0g"
YOUTUBE_CHANNEL_ID_150 = "POCOYOUSA"
YOUTUBE_CHANNEL_ID_151 = "pollypocket"
YOUTUBE_CHANNEL_ID_152 = "UCqrVPwN_DhavUC386xH9SDw"
YOUTUBE_CHANNEL_ID_153 = "preschoolpopstars"
YOUTUBE_CHANNEL_ID_154 = "UC9y5Bed2UVb-kxBOt1nwQIQ"
YOUTUBE_CHANNEL_ID_155 = "UCPdxa631-MvtSXGGJuhGuxw"
YOUTUBE_CHANNEL_ID_156 = "roarytheracingcar"
YOUTUBE_CHANNEL_ID_157 = "UC-5E0ZHSkN6hExW4rDCY4vw"
YOUTUBE_CHANNEL_ID_158 = "PLjr_J_DQd6zcUiDPE7PNIiksADYwoThUR"
YOUTUBE_CHANNEL_ID_159 = "PLnAsr_cuPGAMt27PHMz1X4zZTE5kGS03E"
YOUTUBE_CHANNEL_ID_160 = "scishowkids"
YOUTUBE_CHANNEL_ID_161 = "SesameStreet"
YOUTUBE_CHANNEL_ID_162 = "UCn--vKxbXBYt_b0lKJ0JEnw"
YOUTUBE_CHANNEL_ID_163 = "dhxretrotv"
YOUTUBE_CHANNEL_ID_164 = "storybots"
YOUTUBE_CHANNEL_ID_165 = "PLjr_J_DQd6zfw-8gWQ3QONYCmE6lDq41X"
YOUTUBE_CHANNEL_ID_166 = "PLWi6nzVYwR37LNe7R7sxHdZalXxOqbcF3"
YOUTUBE_CHANNEL_ID_167 = "TalkingFriends"
YOUTUBE_CHANNEL_ID_168 = "shows4learning"
YOUTUBE_CHANNEL_ID_169 = "PLuWVtqjbiBSPI_p3CV1DtIoxQY_uU6qN8"
YOUTUBE_CHANNEL_ID_170 = "thepoochesonline"
YOUTUBE_CHANNEL_ID_171 = "UCns6sGDoRVhrND8npcvGLSw"
YOUTUBE_CHANNEL_ID_172 = "PLQpyrMU5mb00wWBHRq0uB0X51rh7zWn1K"
YOUTUBE_CHANNEL_ID_173 = "TheHolyTales"
YOUTUBE_CHANNEL_ID_174 = "UCnRuuiSVqDF2EmoYS7yE6ZA"
YOUTUBE_CHANNEL_ID_175 = "PLonGtgtV8MRdh6_ys6SqAU4jttR8Xbo-r"
YOUTUBE_CHANNEL_ID_176 = "FunLearning100"
YOUTUBE_CHANNEL_ID_177 = "PLjr_J_DQd6zeMh0m0aobkvmxrSTCDqgx5"
YOUTUBE_CHANNEL_ID_178 = "Toddlerfunlearning"
YOUTUBE_CHANNEL_ID_179 = "ToobysEnglish"
YOUTUBE_CHANNEL_ID_180 = "PLdAOY_vKneiBrNRt-9m0-jkLhqMtwLQ3V"
YOUTUBE_CHANNEL_ID_181 = "UC61e7CRqGJGJS41xQzd-yyw" 
YOUTUBE_CHANNEL_ID_182 = "TreehouseDirect"
YOUTUBE_CHANNEL_ID_183 = "UChDfzt74pzK8S7yjT147JjA"
YOUTUBE_CHANNEL_ID_184 = "BigIdeaInc"
YOUTUBE_CHANNEL_ID_185 = "videogyan"
YOUTUBE_CHANNEL_ID_186 = "UC0WpBLqS4o_cRdMv6yBcT9g"
YOUTUBE_CHANNEL_ID_187 = "UCxEmDFo1yUbbxjEb9RjitVA"
YOUTUBE_CHANNEL_ID_188 = "UCQUSXgYhQjWQFD_oGjR9uNw"
YOUTUBE_CHANNEL_ID_189 = "UCcKJJuOe2tOqgrKw0Gks-sw"
YOUTUBE_CHANNEL_ID_190 = "ZouOfficial"
YOUTUBE_CHANNEL_ID_191 = "UCzsln6W-RnoIrkWkp4oeNHw"
YOUTUBE_CHANNEL_ID_192 = "UCp5ebGI3ime0kOji9IkkRgg"




# Entry point
def run():
    plugintools.log("docu.run")
    
    # Get params
    params = plugintools.get_params()
    
    if params.get("action") is None:
        main_list(params)
    else:
        action = params.get("action")
        exec action+"(params)"
    
    plugintools.close_item_list()

# Main menu
def main_list(params):
    plugintools.log("docu.main_list "+repr(params))
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR cornflowerblue]==================== Español ====================[/COLOR]",
        url="plugin://plugin.video.youtube/user/"+YOUTUBE_CHANNEL_ID_1+"/",
        thumbnail="http://mybuild.darkwebrepo.gq/infantil/spanish.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR cornflowerblue]1. A Bebés Contentos[/COLOR]",
        url="plugin://plugin.video.youtube/channel/"+YOUTUBE_CHANNEL_ID_2+"/",
        thumbnail="http://mybuild.darkwebrepo.gq/infantil/abebes.jpg",
        folder=True )	
	
    plugintools.add_item( 
        #action="", 
        title="[COLOR cornflowerblue]2. A Tiempo Preescolar[/COLOR]",
        url="plugin://plugin.video.youtube/user/"+YOUTUBE_CHANNEL_ID_3+"/",
        thumbnail="http://mybuild.darkwebrepo.gq/infantil/atiempo.jpg",
        folder=True )
	
    plugintools.add_item( 
        #action="", 
        title="[COLOR cornflowerblue]3. Angelina Ballerina[/COLOR]",
        url="plugin://plugin.video.youtube/channel/"+YOUTUBE_CHANNEL_ID_4+"/",
        thumbnail="http://mybuild.darkwebrepo.gq/infantil/angelina.jpg",
        folder=True )	
	
    plugintools.add_item( 
        #action="", 
        title="[COLOR cornflowerblue]4. Aprende conmigo - ABC123[/COLOR]",
        url="plugin://plugin.video.youtube/channel/"+YOUTUBE_CHANNEL_ID_5+"/",
        thumbnail="http://mybuild.darkwebrepo.gq/infantil/abc.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR cornflowerblue]5. Atención Atención[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_6+"/",
        thumbnail="http://mybuild.darkwebrepo.gq/infantil/atencion.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR cornflowerblue]6. Auto City[/COLOR]",
        url="plugin://plugin.video.youtube/user/"+YOUTUBE_CHANNEL_ID_7+"/",
        thumbnail="http://mybuild.darkwebrepo.gq/infantil/auto.jpg",
        folder=True )
	
    plugintools.add_item( 
        #action="", 
        title="[COLOR cornflowerblue]7. Aventuras con los Kratt[/COLOR]",
        url="plugin://plugin.video.youtube/channel/"+YOUTUBE_CHANNEL_ID_8+"/",
        thumbnail="http://mybuild.darkwebrepo.gq/infantil/kratt.jpg",
        folder=True )
			
    plugintools.add_item( 
        #action="", 
        title="[COLOR cornflowerblue]8. Babyradio[/COLOR]",
        url="plugin://plugin.video.youtube/channel/"+YOUTUBE_CHANNEL_ID_9+"/",
        thumbnail="http://mybuild.darkwebrepo.gq/infantil/Babyradio.jpg",
        folder=True )
				
    plugintools.add_item( 
        #action="", 
        title="[COLOR cornflowerblue]9. Baby TV[/COLOR]",
        url="plugin://plugin.video.youtube/user/"+YOUTUBE_CHANNEL_ID_10+"/",
        thumbnail="http://mybuild.darkwebrepo.gq/infantil/babytv.jpg",
        folder=True )
					
    plugintools.add_item( 
        #action="", 
        title="[COLOR cornflowerblue]10. Bananas En Pijamas[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_11+"/",
        thumbnail="http://mybuild.darkwebrepo.gq/infantil/bananas.jpg",
        folder=True )
					
    plugintools.add_item( 
        #action="", 
        title="[COLOR cornflowerblue]11. Barbie[/COLOR]",
        url="plugin://plugin.video.youtube/channel/"+YOUTUBE_CHANNEL_ID_12+"/",
        thumbnail="http://mybuild.darkwebrepo.gq/infantil/barbie.jpg",
        folder=True )	
				
    plugintools.add_item( 
        #action="", 
        title="[COLOR cornflowerblue]12. Barney[/COLOR]",
        url="plugin://plugin.video.youtube/channel/"+YOUTUBE_CHANNEL_ID_13+"/",
        thumbnail="http://mybuild.darkwebrepo.gq/infantil/barney.jpg",
        folder=True )	
			
    plugintools.add_item( 
        #action="", 
        title="[COLOR cornflowerblue]13. Biper y Sus Amigos[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_14+"/",
        thumbnail="http://mybuild.darkwebrepo.gq/infantil/biper.jpg",
        folder=True )	
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR cornflowerblue]14. Boom & Reds[/COLOR]",
        url="plugin://plugin.video.youtube/user/"+YOUTUBE_CHANNEL_ID_15+"/",
        thumbnail="http://mybuild.darkwebrepo.gq/infantil/boom&reds.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR cornflowerblue]15. Booya[/COLOR]",
        url="plugin://plugin.video.youtube/channel/"+YOUTUBE_CHANNEL_ID_16+"/",
        thumbnail="http://mybuild.darkwebrepo.gq/infantil/booya.jpg",
        folder=True )	
	
    plugintools.add_item( 
        #action="", 
        title="[COLOR cornflowerblue]16. Caillou[/COLOR]",
        url="plugin://plugin.video.youtube/channel/"+YOUTUBE_CHANNEL_ID_17+"/",
        thumbnail="http://mybuild.darkwebrepo.gq/infantil/caillou.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR cornflowerblue]17. Canal Pakapaka[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_18+"/",
        thumbnail="http://mybuild.darkwebrepo.gq/infantil/pakapaka.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR cornflowerblue]18. Cantando Aprendo a Hablar[/COLOR]",
        url="plugin://plugin.video.youtube/user/"+YOUTUBE_CHANNEL_ID_19+"/",
        thumbnail="http://mybuild.darkwebrepo.gq/infantil/cantandoaprendo.jpg",
        folder=True )
			
    plugintools.add_item( 
        #action="", 
        title="[COLOR cornflowerblue]19. Charlie y Lola[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_20+"/",
        thumbnail="http://mybuild.darkwebrepo.gq/infantil/charlieylola.jpg",
        folder=True )	
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR cornflowerblue]20. Chavoanimadoable[/COLOR]",
        url="plugin://plugin.video.youtube/user/"+YOUTUBE_CHANNEL_ID_21+"/",
        thumbnail="http://mybuild.darkwebrepo.gq/infantil/chavoanimado.jpg",
        folder=True )	
	
    plugintools.add_item( 
        #action="", 
        title="[COLOR cornflowerblue]21. Chotoonz TV[/COLOR]",
        url="plugin://plugin.video.youtube/channel/"+YOUTUBE_CHANNEL_ID_22+"/",
        thumbnail="http://mybuild.darkwebrepo.gq/infantil/chotoonztv.jpg",
        folder=True )	
	
    plugintools.add_item( 
        #action="", 
        title="[COLOR cornflowerblue]22. ChuChu TV[/COLOR]",
        url="plugin://plugin.video.youtube/channel/"+YOUTUBE_CHANNEL_ID_23+"/",
        thumbnail="http://mybuild.darkwebrepo.gq/infantil/chuchu.jpg",
        folder=True )
				
    plugintools.add_item( 
        #action="", 
        title="[COLOR cornflowerblue]23. Chuggingtong[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_24+"/",
        thumbnail="http://mybuild.darkwebrepo.gq/infantil/chuggingtong.jpg",
        folder=True )	
			
    plugintools.add_item( 
        #action="", 
        title="[COLOR cornflowerblue]24. CNTV Infantil[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_25+"/",
        thumbnail="http://mybuild.darkwebrepo.gq/infantil/cntv.jpg",
        folder=True )	
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR cornflowerblue]25. Cuentos Infantiles Cortos[/COLOR]",
        url="plugin://plugin.video.youtube/channel/"+YOUTUBE_CHANNEL_ID_26+"/",
        thumbnail="http://mybuild.darkwebrepo.gq/infantil/cuentos-cortos.jpg",
        folder=True )
				
    plugintools.add_item( 
        #action="", 
        title="[COLOR cornflowerblue]26. Dave and Ava[/COLOR]",
        url="plugin://plugin.video.youtube/channel/"+YOUTUBE_CHANNEL_ID_27+"/",
        thumbnail="http://mybuild.darkwebrepo.gq/infantil/daveava.jpg",
        folder=True )	
			
    plugintools.add_item( 
        #action="", 
        title="[COLOR cornflowerblue]27. Doctor Beet[/COLOR]",
        url="plugin://plugin.video.youtube/channel/"+YOUTUBE_CHANNEL_ID_28+"/",
        thumbnail="http://mybuild.darkwebrepo.gq/infantil/doctorbeet.jpg",
        folder=True )
			
    plugintools.add_item( 
        #action="", 
        title="[COLOR cornflowerblue]28. Doremi[/COLOR]",
        url="plugin://plugin.video.youtube/channel/"+YOUTUBE_CHANNEL_ID_29+"/",
        thumbnail="http://mybuild.darkwebrepo.gq/infantil/doremi.jpg",
        folder=True )	
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR cornflowerblue]29. El Mundo de Luna[/COLOR]",
        url="plugin://plugin.video.youtube/channel/"+YOUTUBE_CHANNEL_ID_30+"/",
        thumbnail="http://mybuild.darkwebrepo.gq/infantil/luna.jpg",
        folder=True )
	
	
    plugintools.add_item( 
        #action="", 
        title="[COLOR cornflowerblue]30. El Reino a Jugar[/COLOR]",
        url="plugin://plugin.video.youtube/channel/"+YOUTUBE_CHANNEL_ID_31+"/",
        thumbnail="http://mybuild.darkwebrepo.gq/infantil/reinoajugar.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR cornflowerblue]31. El Reino Infantil[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_32+"/",
        thumbnail="http://mybuild.darkwebrepo.gq/infantil/reino.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR cornflowerblue]32. Fairy Tales[/COLOR]",
        url="plugin://plugin.video.youtube/channel/"+YOUTUBE_CHANNEL_ID_33+"/",
        thumbnail="http://mybuild.darkwebrepo.gq/infantil/fairytales.jpg",
        folder=True )	
	
    plugintools.add_item( 
        #action="", 
        title="[COLOR cornflowerblue]33. Familia Telerín[/COLOR]",
        url="plugin://plugin.video.youtube/channel/"+YOUTUBE_CHANNEL_ID_34+"/",
        thumbnail="http://mybuild.darkwebrepo.gq/infantil/telerin.jpg",
        folder=True )
			
    plugintools.add_item( 
        #action="", 
        title="[COLOR cornflowerblue]34. Farmees[/COLOR]",
        url="plugin://plugin.video.youtube/channel/"+YOUTUBE_CHANNEL_ID_35+"/",
        thumbnail="http://mybuild.darkwebrepo.gq/infantil/farmees.jpg",
        folder=True )
			
    plugintools.add_item( 
        #action="", 
        title="[COLOR cornflowerblue]35. Gallina Pintadita[/COLOR]",
        url="plugin://plugin.video.youtube/user/"+YOUTUBE_CHANNEL_ID_36+"/",
        thumbnail="http://mybuild.darkwebrepo.gq/infantil/gallinita.jpg",
        folder=True )	
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR cornflowerblue]36. Happy Learning[/COLOR]",
        url="plugin://plugin.video.youtube/channel/"+YOUTUBE_CHANNEL_ID_37+"/",
        thumbnail="http://mybuild.darkwebrepo.gq/infantil/happy.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR cornflowerblue]37. HeyKids - Canciones Para Niños[/COLOR]",
        url="plugin://plugin.video.youtube/user/"+YOUTUBE_CHANNEL_ID_38+"/",
        thumbnail="http://mybuild.darkwebrepo.gq/infantil/heykids.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR cornflowerblue]38. HooplaKidz[/COLOR]",
        url="plugin://plugin.video.youtube/user/"+YOUTUBE_CHANNEL_ID_39+"/",
        thumbnail="http://mybuild.darkwebrepo.gq/infantil/hooplaKidz.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR cornflowerblue]39. Jaime Tentáculos[/COLOR]",
        url="plugin://plugin.video.youtube/channel/"+YOUTUBE_CHANNEL_ID_40+"/",
        thumbnail="http://mybuild.darkwebrepo.gq/infantil/jaimetentaculos.jpg",
        folder=True )	
	
    plugintools.add_item( 
        #action="", 
        title="[COLOR cornflowerblue]40. JellyJamm[/COLOR]",
        url="plugin://plugin.video.youtube/channel/"+YOUTUBE_CHANNEL_ID_41+"/",
        thumbnail="http://mybuild.darkwebrepo.gq/infantil/jellyjam.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR cornflowerblue]41. Kids Hut - Cuentos[/COLOR]",
        url="plugin://plugin.video.youtube/channel/"+YOUTUBE_CHANNEL_ID_42+"/",
        thumbnail="http://mybuild.darkwebrepo.gq/infantil/kidshut.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR cornflowerblue]42. Las Canciones de la Familia Blu[/COLOR]",
        url="plugin://plugin.video.youtube/channel/"+YOUTUBE_CHANNEL_ID_43+"/",
        thumbnail="http://mybuild.darkwebrepo.gq/infantil/familiablu.jpg",
        folder=True )	
	
    plugintools.add_item( 
        #action="", 
        title="[COLOR cornflowerblue]43. Las Canciones del Zoo[/COLOR]",
        url="plugin://plugin.video.youtube/user/"+YOUTUBE_CHANNEL_ID_44+"/",
        thumbnail="http://mybuild.darkwebrepo.gq/infantil/zoo.jpg",
        folder=True )
			
    plugintools.add_item( 
        #action="", 
        title="[COLOR cornflowerblue]44. La Colmena Feliz[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_45+"/",
        thumbnail="http://mybuild.darkwebrepo.gq/infantil/lacolmena.jpg",
        folder=True )	
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR cornflowerblue]45. La Granja de Zenón[/COLOR]",
        url="plugin://plugin.video.youtube/user/"+YOUTUBE_CHANNEL_ID_46+"/",
        thumbnail="http://mybuild.darkwebrepo.gq/infantil/lagranja.jpg",
        folder=True )	
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR cornflowerblue]46. Little Baby Bum[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_47+"/",
        thumbnail="http://mybuild.darkwebrepo.gq/infantil/boom.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR cornflowerblue]47. Los Pequeñines[/COLOR]",
        url="plugin://plugin.video.youtube/channel/"+YOUTUBE_CHANNEL_ID_48+"/",
        thumbnail="http://mybuild.darkwebrepo.gq/infantil/lospeque%c3%b1ines.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR cornflowerblue]48. Los Octonautas[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_49+"/",
        thumbnail="http://mybuild.darkwebrepo.gq/infantil/octonauts.jpg",
        folder=True )	
	
    plugintools.add_item( 
        #action="", 
        title="[COLOR cornflowerblue]49. Lunacreciente[/COLOR]",
        url="plugin://plugin.video.youtube/user/"+YOUTUBE_CHANNEL_ID_50+"/",
        thumbnail="http://mybuild.darkwebrepo.gq/infantil/lunacreciente.jpg",
        folder=True )
	
    plugintools.add_item( 
        #action="", 
        title="[COLOR cornflowerblue]50. Masha y El Oso[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_51+"/",
        thumbnail="http://mybuild.darkwebrepo.gq/infantil/masha.jpg",
        folder=True )
	
    plugintools.add_item( 
        #action="", 
        title="[COLOR cornflowerblue]51. Mi Casita[/COLOR]",
        url="plugin://plugin.video.youtube/channel/"+YOUTUBE_CHANNEL_ID_52+"/",
        thumbnail="http://mybuild.darkwebrepo.gq/infantil/micasita.jpg",
        folder=True )	

    plugintools.add_item( 
        #action="", 
        title="[COLOR cornflowerblue]52. Mi Pequeña Biblia[/COLOR]",
        url="plugin://plugin.video.youtube/channel/"+YOUTUBE_CHANNEL_ID_53+"/",
        thumbnail="http://mybuild.darkwebrepo.gq/infantil/biblia.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR cornflowerblue]53. Monocíclope[/COLOR]",
        url="plugin://plugin.video.youtube/user/"+YOUTUBE_CHANNEL_ID_54+"/",
        thumbnail="http://mybuild.darkwebrepo.gq/infantil/monociclope.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR cornflowerblue]54. Nina Tiene Que Ir[/COLOR]",
        url="plugin://plugin.video.youtube/channel/"+YOUTUBE_CHANNEL_ID_55+"/",
        thumbnail="http://mybuild.darkwebrepo.gq/infantil/ninatienequeir.jpg",
        folder=True )	
	
    plugintools.add_item( 
        #action="", 
        title="[COLOR cornflowerblue]55. Payaso Remi TV[/COLOR]",
        url="plugin://plugin.video.youtube/channel/"+YOUTUBE_CHANNEL_ID_56+"/",
        thumbnail="http://mybuild.darkwebrepo.gq/infantil/remi.jpg",
        folder=True )	

    plugintools.add_item( 
        #action="", 
        title="[COLOR cornflowerblue]56. Peppa Pig[/COLOR]",
        url="plugin://plugin.video.youtube/channel/"+YOUTUBE_CHANNEL_ID_57+"/",
        thumbnail="http://mybuild.darkwebrepo.gq/infantil/peppa.jpg",
        folder=True )
			
    plugintools.add_item( 
        #action="", 
        title="[COLOR cornflowerblue]57. Pequeños Heroes[/COLOR]",
        url="plugin://plugin.video.youtube/channel/"+YOUTUBE_CHANNEL_ID_58+"/",
        thumbnail="http://mybuild.darkwebrepo.gq/infantil/heroes.jpg",
        folder=True )
			
    plugintools.add_item( 
        #action="", 
        title="[COLOR cornflowerblue]58. Peztronauta[/COLOR]",
        url="plugin://plugin.video.youtube/channel/"+YOUTUBE_CHANNEL_ID_59+"/",
        thumbnail="http://mybuild.darkwebrepo.gq/infantil/peztronauta.jpg",
        folder=True )	
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR cornflowerblue]59. Pica Pica[/COLOR]",
        url="plugin://plugin.video.youtube/user/"+YOUTUBE_CHANNEL_ID_60+"/",
        thumbnail="http://mybuild.darkwebrepo.gq/infantil/pica-pica.jpg",
        folder=True )	
	
    plugintools.add_item( 
        #action="", 
        title="[COLOR cornflowerblue]60. Piccolo Mondo PR[/COLOR]",
        url="plugin://plugin.video.youtube/user/"+YOUTUBE_CHANNEL_ID_61+"/",
        thumbnail="http://mybuild.darkwebrepo.gq/infantil/piccolomundo.jpg",
        folder=True )
			
    plugintools.add_item( 
        #action="", 
        title="[COLOR cornflowerblue]61. Pinkfong![/COLOR]",
        url="plugin://plugin.video.youtube/channel/"+YOUTUBE_CHANNEL_ID_62+"/",
        thumbnail="http://mybuild.darkwebrepo.gq/infantil/pinkfong.jpg",
        folder=True )
			
    plugintools.add_item( 
        #action="", 
        title="[COLOR cornflowerblue]62. PJ Mask[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_63+"/",
        thumbnail="http://mybuild.darkwebrepo.gq/infantil/pjmask.jpg",
        folder=True )
				
    plugintools.add_item( 
        #action="", 
        title="[COLOR cornflowerblue]63. Playgroung Juli y Juanchi[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_64+"/",
        thumbnail="http://mybuild.darkwebrepo.gq/infantil/juliJuanchi.jpg",
        folder=True )	
			
    plugintools.add_item( 
        #action="", 
        title="[COLOR cornflowerblue]64. Plim Plim[/COLOR]",
        url="plugin://plugin.video.youtube/user/"+YOUTUBE_CHANNEL_ID_65+"/",
        thumbnail="http://mybuild.darkwebrepo.gq/infantil/plim.jpg",
        folder=True )		
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR cornflowerblue]65. Pocoyo[/COLOR]",
        url="plugin://plugin.video.youtube/channel/"+YOUTUBE_CHANNEL_ID_66+"/",
        thumbnail="http://mybuild.darkwebrepo.gq/infantil/pocoyo.jpg",
        folder=True )	
	
    plugintools.add_item( 
        #action="", 
        title="[COLOR cornflowerblue]66. Polly Pocket[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_67+"/",
        thumbnail="http://mybuild.darkwebrepo.gq/infantil/polly.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR cornflowerblue]67. PINY[/COLOR]",
        url="plugin://plugin.video.youtube/channel/"+YOUTUBE_CHANNEL_ID_68+"/",
        thumbnail="http://mybuild.darkwebrepo.gq/infantil/piny.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR cornflowerblue]68. Pucca[/COLOR]",
        url="plugin://plugin.video.youtube/channel/"+YOUTUBE_CHANNEL_ID_69+"/",
        thumbnail="http://mybuild.darkwebrepo.gq/infantil/pucca.jpg",
        folder=True )	
	
    plugintools.add_item( 
        #action="", 
        title="[COLOR cornflowerblue]69. Rosita Fresita[/COLOR]",
        url="plugin://plugin.video.youtube/user/"+YOUTUBE_CHANNEL_ID_70+"/",
        thumbnail="http://mybuild.darkwebrepo.gq/infantil/rosita.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR cornflowerblue]70. Sam el Bombero[/COLOR]",
        url="plugin://plugin.video.youtube/channel/"+YOUTUBE_CHANNEL_ID_71+"/",
        thumbnail="http://mybuild.darkwebrepo.gq/infantil/firemansam.jpg",
        folder=True )	
	
    plugintools.add_item( 
        #action="", 
        title="[COLOR cornflowerblue]71. Sésamo[/COLOR]",
        url="plugin://plugin.video.youtube/user/"+YOUTUBE_CHANNEL_ID_72+"/",
        thumbnail="http://mybuild.darkwebrepo.gq/infantil/sesamo.jpg",
        folder=True )
			
    plugintools.add_item( 
        #action="", 
        title="[COLOR cornflowerblue]72. Tayo El Pequeño Autobús[/COLOR]",
        url="plugin://plugin.video.youtube/channel/"+YOUTUBE_CHANNEL_ID_73+"/",
        thumbnail="http://mybuild.darkwebrepo.gq/infantil/tayo.jpg",
        folder=True )	
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR cornflowerblue]73. Teletubbies[/COLOR]",
        url="plugin://plugin.video.youtube/channel/"+YOUTUBE_CHANNEL_ID_74+"/",
        thumbnail="http://mybuild.darkwebrepo.gq/infantil/teletubbies.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR cornflowerblue]74. Tiempo De Sol[/COLOR]",
        url="plugin://plugin.video.youtube/user/"+YOUTUBE_CHANNEL_ID_75+"/",
        thumbnail="http://mybuild.darkwebrepo.gq/infantil/tiempodesol.jpg",
        folder=True )	
	
    plugintools.add_item( 
        #action="", 
        title="[COLOR cornflowerblue]75. Tio Spanish: Aprender Español[/COLOR]",
        url="plugin://plugin.video.youtube/user/"+YOUTUBE_CHANNEL_ID_76+"/",
        thumbnail="http://mybuild.darkwebrepo.gq/infantil/tiospanish.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR cornflowerblue]76. Traposo TV[/COLOR]",
        url="plugin://plugin.video.youtube/user/"+YOUTUBE_CHANNEL_ID_77+"/",
        thumbnail="http://mybuild.darkwebrepo.gq/infantil/traposo.jpg",
        folder=True )	
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR cornflowerblue]77. Treehouse Direct[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_78+"/",
        thumbnail="http://mybuild.darkwebrepo.gq/infantil/treehousees.jpg",
        folder=True )	
	
    plugintools.add_item( 
        #action="", 
        title="[COLOR cornflowerblue]78. Todo es Rosie[/COLOR]",
        url="plugin://plugin.video.youtube/user/"+YOUTUBE_CHANNEL_ID_79+"/",
        thumbnail="http://mybuild.darkwebrepo.gq/infantil/todorosie.jpg",
        folder=True )
	
    plugintools.add_item( 
        #action="", 
        title="[COLOR cornflowerblue]79. Tom y sus Amigos[/COLOR]",
        url="plugin://plugin.video.youtube/channel/"+YOUTUBE_CHANNEL_ID_80+"/",
        thumbnail="http://mybuild.darkwebrepo.gq/infantil/talkingtom.jpg",
        folder=True )	

    plugintools.add_item( 
        #action="", 
        title="[COLOR cornflowerblue]80. Toobys[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_81+"/",
        thumbnail="http://mybuild.darkwebrepo.gq/infantil/toobys.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR cornflowerblue]81. TuTiTu[/COLOR]",
        url="plugin://plugin.video.youtube/user/"+YOUTUBE_CHANNEL_ID_82+"/",
        thumbnail="http://mybuild.darkwebrepo.gq/infantil/tutitu.jpg",
        folder=True )	
	
    plugintools.add_item( 
        #action="", 
        title="[COLOR cornflowerblue]82. Tu y yo Cantando[/COLOR]",
        url="plugin://plugin.video.youtube/user/"+YOUTUBE_CHANNEL_ID_83+"/",
        thumbnail="http://mybuild.darkwebrepo.gq/infantil/tuyyo.jpg",
        folder=True )
	
    plugintools.add_item( 
        #action="", 
        title="[COLOR cornflowerblue]83. Un día en Once Niños[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_84+"/",
        thumbnail="http://mybuild.darkwebrepo.gq/infantil/onceninos.jpg",
        folder=True )	

    plugintools.add_item( 
        #action="", 
        title="[COLOR cornflowerblue]84. Wildbrain[/COLOR]",
        url="plugin://plugin.video.youtube/user/"+YOUTUBE_CHANNEL_ID_85+"/",
        thumbnail="http://mybuild.darkwebrepo.gq/infantil/wild.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLOR cornflowerblue]85. ZOU[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_86+"/",
        thumbnail="http://mybuild.darkwebrepo.gq/infantil/zou.jpg",
        folder=True )
			
    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]==================== Ingles ====================[/COLOR]",
        url="plugin://plugin.video.youtube/user/"+YOUTUBE_CHANNEL_ID_87+"/",
        thumbnail="http://mybuild.darkwebrepo.gq/infantil/english.jpg",
        folder=True )
					
    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]1. ABCkid TV[/COLOR]",
        url="plugin://plugin.video.youtube/user/"+YOUTUBE_CHANNEL_ID_88+"/",
        thumbnail="http://mybuild.darkwebrepo.gq/infantil/abckidTV.jpg",
        folder=True )
						
    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]2. Alphablocks[/COLOR]",
        url="plugin://plugin.video.youtube/channel/"+YOUTUBE_CHANNEL_ID_89+"/",
        thumbnail="http://mybuild.darkwebrepo.gq/infantil/alphablocks.jpg",
        folder=True )	
					
    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]3. All Babies Channel[/COLOR]",
        url="plugin://plugin.video.youtube/user/"+YOUTUBE_CHANNEL_ID_90+"/",
        thumbnail="http://mybuild.darkwebrepo.gq/infantil/allbabieschannel.jpg",
        folder=True )
						
    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]4. All Things Animal TV[/COLOR]",
        url="plugin://plugin.video.youtube/channel/"+YOUTUBE_CHANNEL_ID_91+"/",
        thumbnail="http://mybuild.darkwebrepo.gq/infantil/allthingsanimal.jpg",
        folder=True )	
					
    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]5. Angelina Ballerina[/COLOR]",
        url="plugin://plugin.video.youtube/user/"+YOUTUBE_CHANNEL_ID_92+"/",
        thumbnail="http://mybuild.darkwebrepo.gq/infantil/angelina.jpg",
        folder=True )
						
    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]6. Animal Mechanicals[/COLOR]",
        url="plugin://plugin.video.youtube/channel/"+YOUTUBE_CHANNEL_ID_93+"/",
        thumbnail="http://mybuild.darkwebrepo.gq/infantil/animalmechanicals.jpg",
        folder=True )
							
    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]7. Arpo The Robot[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_94+"/",
        thumbnail="http://mybuild.darkwebrepo.gq/infantil/arpotherobot.jpg",
        folder=True )	
						
    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]8. Baby Bao Panda[/COLOR]",
        url="plugin://plugin.video.youtube/channel/"+YOUTUBE_CHANNEL_ID_95+"/",
        thumbnail="http://mybuild.darkwebrepo.gq/infantil/babyboo.jpg",
        folder=True )	
					
    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]9. Baby TV[/COLOR]",
        url="plugin://plugin.video.youtube/user/"+YOUTUBE_CHANNEL_ID_96+"/",
        thumbnail="http://mybuild.darkwebrepo.gq/infantil/babytv.jpg",
        folder=True )
						
    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]10. Barbie[/COLOR]",
        url="plugin://plugin.video.youtube/user/"+YOUTUBE_CHANNEL_ID_97+"/",
        thumbnail="http://mybuild.darkwebrepo.gq/infantil/barbie.jpg",
        folder=True )
					
    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]11. Barbie Cartoon[/COLOR]",
        url="plugin://plugin.video.youtube/channel/"+YOUTUBE_CHANNEL_ID_98+"/",
        thumbnail="http://mybuild.darkwebrepo.gq/infantil/barbiecartoon.jpg",
        folder=True )	
				
    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]12. Barney Episodes[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_99+"/",
        thumbnail="http://mybuild.darkwebrepo.gq/infantil/barney.jpg",
        folder=True )	
			
    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]13. Badanamu[/COLOR]",
        url="plugin://plugin.video.youtube/user/"+YOUTUBE_CHANNEL_ID_100+"/",
        thumbnail="http://mybuild.darkwebrepo.gq/infantil/badanamu.jpg",
        folder=True )
				
    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]14. Bananas In Pyjamas[/COLOR]",
        url="plugin://plugin.video.youtube/user/"+YOUTUBE_CHANNEL_ID_101+"/",
        thumbnail="http://mybuild.darkwebrepo.gq/infantil/bananas.jpg",
        folder=True )
								
    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]15. Binkie TV[/COLOR]",
        url="plugin://plugin.video.youtube/user/"+YOUTUBE_CHANNEL_ID_102+"/",
        thumbnail="http://mybuild.darkwebrepo.gq/infantil/blinkie.jpg",
        folder=True )
								
    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]16. Blaze & The Monters Machine[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_103+"/",
        thumbnail="http://mybuild.darkwebrepo.gq/infantil/blazes.jpg",
        folder=True )	
							
    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]17. Bo on the Go![/COLOR]",
        url="plugin://plugin.video.youtube/channel/"+YOUTUBE_CHANNEL_ID_104+"/",
        thumbnail="http://mybuild.darkwebrepo.gq/infantil/boonthego.jpg",
        folder=True )
								
    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]18. Bob the Builder[/COLOR]",
        url="plugin://plugin.video.youtube/user/"+YOUTUBE_CHANNEL_ID_105+"/",
        thumbnail="http://mybuild.darkwebrepo.gq/infantil/bobthebuilder.jpg",
        folder=True )	
							
    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]19. Booba[/COLOR]",
        url="plugin://plugin.video.youtube/user/"+YOUTUBE_CHANNEL_ID_106+"/",
        thumbnail="http://mybuild.darkwebrepo.gq/infantil/booba.jpg",
        folder=True )
							
    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]20. Busy Beavers[/COLOR]",
        url="plugin://plugin.video.youtube/user/"+YOUTUBE_CHANNEL_ID_107+"/",
        thumbnail="http://mybuild.darkwebrepo.gq/infantil/beaver.jpg",
        folder=True )
								
    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]21. Buzz Bumble[/COLOR]",
        url="plugin://plugin.video.youtube/channel/"+YOUTUBE_CHANNEL_ID_108+"/",
        thumbnail="http://mybuild.darkwebrepo.gq/infantil/buzzbumble.jpg",
        folder=True )
								
    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]22. Cartoon Candy[/COLOR]",
        url="plugin://plugin.video.youtube/channel/"+YOUTUBE_CHANNEL_ID_109+"/",
        thumbnail="http://mybuild.darkwebrepo.gq/infantil/candycartoon.jpg",
        folder=True )
								
    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]23. Chloe's Closet[/COLOR]",
        url="plugin://plugin.video.youtube/user/"+YOUTUBE_CHANNEL_ID_110+"/",
        thumbnail="http://mybuild.darkwebrepo.gq/infantil/chloescloset.jpg",
        folder=True )	
							
    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]24. ChuChu TV[/COLOR]",
        url="plugin://plugin.video.youtube/user/"+YOUTUBE_CHANNEL_ID_111+"/",
        thumbnail="http://mybuild.darkwebrepo.gq/infantil/chuchutv1.jpg",
        folder=True )
							
    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]25. ChuChu TV Funzone[/COLOR]",
        url="plugin://plugin.video.youtube/channel/"+YOUTUBE_CHANNEL_ID_112+"/",
        thumbnail="http://mybuild.darkwebrepo.gq/infantil/chuchufunnzone.jpg",
        folder=True )
									
    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]26. Cloudbabies[/COLOR]",
        url="plugin://plugin.video.youtube/channel/"+YOUTUBE_CHANNEL_ID_113+"/",
        thumbnail="http://mybuild.darkwebrepo.gq/infantil/cloudbabies.jpg",
        folder=True )
								
    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]27. Dinopaws[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_114+"/",
        thumbnail="http://mybuild.darkwebrepo.gq/infantil/dinopaws.jpg",
        folder=True )	
							
    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]28. Enchantimals[/COLOR]",
        url="plugin://plugin.video.youtube/channel/"+YOUTUBE_CHANNEL_ID_115+"/",
        thumbnail="http://mybuild.darkwebrepo.gq/infantil/enchantimals.jpg",
        folder=True )
								
    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]29. Everything's Rosie[/COLOR]",
        url="plugin://plugin.video.youtube/user/"+YOUTUBE_CHANNEL_ID_116+"/",
        thumbnail="http://mybuild.darkwebrepo.gq/infantil/everythingrosie.jpg",
        folder=True )	
							
    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]30. Farmees[/COLOR]",
        url="plugin://plugin.video.youtube/channel/"+YOUTUBE_CHANNEL_ID_117+"/",
        thumbnail="http://mybuild.darkwebrepo.gq/infantil/farmeesenglish.jpg",
        folder=True )
							
    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]31. Fifi and The Flowertots[/COLOR]",
        url="plugin://plugin.video.youtube/channel/"+YOUTUBE_CHANNEL_ID_118+"/",
        thumbnail="http://mybuild.darkwebrepo.gq/infantil/fifi.jpg",
        folder=True )	
						
    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]32. Fireman Sam[/COLOR]",
        url="plugin://plugin.video.youtube/user/"+YOUTUBE_CHANNEL_ID_119+"/",
        thumbnail="http://mybuild.darkwebrepo.gq/infantil/firemansam.jpg",
        folder=True )
						
    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]33. Fisher-Price Little People[/COLOR]",
        url="plugin://plugin.video.youtube/user/"+YOUTUBE_CHANNEL_ID_120+"/",
        thumbnail="http://mybuild.darkwebrepo.gq/infantil/littlepeople.jpg",
        folder=True )
										
    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]34. Get Well Soon[/COLOR]",
        url="plugin://plugin.video.youtube/channel/"+YOUTUBE_CHANNEL_ID_121+"/",
        thumbnail="http://mybuild.darkwebrepo.gq/infantil/getwellsoon.jpg",
        folder=True )	
									
    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]35. G.O zMickz[/COLOR]",
        url="plugin://plugin.video.youtube/channel/"+YOUTUBE_CHANNEL_ID_122+"/",
        thumbnail="http://mybuild.darkwebrepo.gq/infantil/mickey.jpg",
        folder=True )	
								
    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]36. Happy Learning[/COLOR]",
        url="plugin://plugin.video.youtube/channel/"+YOUTUBE_CHANNEL_ID_123+"/",
        thumbnail="http://mybuild.darkwebrepo.gq/infantil/happy.jpg",
        folder=True )
								
    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]37. Henry Hugglemonster[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_124+"/",
        thumbnail="http://mybuild.darkwebrepo.gq/infantil/hugglemonster.jpg",
        folder=True )	
							
    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]38. Heroes of the City[/COLOR]",
        url="plugin://plugin.video.youtube/channel/"+YOUTUBE_CHANNEL_ID_125+"/",
        thumbnail="http://mybuild.darkwebrepo.gq/infantil/heroescity.jpg",
        folder=True )
										
    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]39. Iconicles[/COLOR]",
        url="plugin://plugin.video.youtube/channel/"+YOUTUBE_CHANNEL_ID_126+"/",
        thumbnail="http://mybuild.darkwebrepo.gq/infantil/iconicles.jpg",
        folder=True )
										
    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]40. Kid Game Learn videos for Kids[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_127+"/",
        thumbnail="http://mybuild.darkwebrepo.gq/infantil/kidsgame.jpg",
        folder=True )		
									
    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]41. KiiYii[/COLOR]",
        url="plugin://plugin.video.youtube/channel/"+YOUTUBE_CHANNEL_ID_128+"/",
        thumbnail="http://mybuild.darkwebrepo.gq/infantil/kiikii.jpg",
        folder=True )	
								
    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]42. Kikoriki[/COLOR]",
        url="plugin://plugin.video.youtube/user/"+YOUTUBE_CHANNEL_ID_129+"/",
        thumbnail="http://mybuild.darkwebrepo.gq/infantil/kikoriki.jpg",
        folder=True )
								
    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]43. Larva[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_130+"/",
        thumbnail="http://mybuild.darkwebrepo.gq/infantil/larva.jpg",
        folder=True )	
							
    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]44. LazyTown[/COLOR]",
        url="plugin://plugin.video.youtube/user/"+YOUTUBE_CHANNEL_ID_131+"/",
        thumbnail="http://mybuild.darkwebrepo.gq/infantil/lazytown.jpg",
        folder=True )	
						
    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]45. Learn with me - ABC123[/COLOR]",
        url="plugin://plugin.video.youtube/channel/"+YOUTUBE_CHANNEL_ID_132+"/",
        thumbnail="http://mybuild.darkwebrepo.gq/infantil/abc.jpg",
        folder=True )
							
    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]46. Les Dalton[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_133+"/",
        thumbnail="http://mybuild.darkwebrepo.gq/infantil/lesdalton.jpg",
        folder=True )	
						
    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]47. Little Baby Bum[/COLOR]",
        url="plugin://plugin.video.youtube/user/"+YOUTUBE_CHANNEL_ID_134+"/",
        thumbnail="http://mybuild.darkwebrepo.gq/infantil/boom.jpg",
        folder=True )
							
    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]48. Little Charley Bear[/COLOR]",
        url="plugin://plugin.video.youtube/channel/"+YOUTUBE_CHANNEL_ID_135+"/",
        thumbnail="http://mybuild.darkwebrepo.gq/infantil/charlithebear.jpg",
        folder=True )	
						
    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]49. Little Einsteins[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_136+"/",
        thumbnail="http://mybuild.darkwebrepo.gq/infantil/littleeinsteins.jpg",
        folder=True )	
					
    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]50. Luke and Lily[/COLOR]",
        url="plugin://plugin.video.youtube/channel/"+YOUTUBE_CHANNEL_ID_137+"/",
        thumbnail="http://mybuild.darkwebrepo.gq/infantil/lukelily.jpg",
        folder=True )
								
    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]51. LooLoo Kids[/COLOR]",
        url="plugin://plugin.video.youtube/user/"+YOUTUBE_CHANNEL_ID_138+"/",
        thumbnail="http://mybuild.darkwebrepo.gq/infantil/looloo.jpg",
        folder=True )
															
    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]52. Masha and The Bear[/COLOR]",
        url="plugin://plugin.video.youtube/user/"+YOUTUBE_CHANNEL_ID_139+"/",
        thumbnail="http://mybuild.darkwebrepo.gq/infantil/masha&bear.jpg",
        folder=True )	
														
    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]53. Miniforce[/COLOR]",
        url="plugin://plugin.video.youtube/channel/"+YOUTUBE_CHANNEL_ID_140+"/",
        thumbnail="http://mybuild.darkwebrepo.gq/infantil/miniforce.jpg",
        folder=True )		
													
    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]54. Noddy[/COLOR]",
        url="plugin://plugin.video.youtube/channel/"+YOUTUBE_CHANNEL_ID_141+"/",
        thumbnail="http://mybuild.darkwebrepo.gq/infantil/noody.jpg",
        folder=True )	
												
    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]55. Octonauts[/COLOR]",
        url="plugin://plugin.video.youtube/channel/"+YOUTUBE_CHANNEL_ID_142+"/",
        thumbnail="http://mybuild.darkwebrepo.gq/infantil/octonauts.jpg",
        folder=True )	
											
    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]56. Oggy and the Cockroaches[/COLOR]",
        url="plugin://plugin.video.youtube/channel/"+YOUTUBE_CHANNEL_ID_143+"/",
        thumbnail="http://mybuild.darkwebrepo.gq/infantil/oggy.jpg",
        folder=True )
												
    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]57. Olivia The Pig[/COLOR]",
        url="plugin://plugin.video.youtube/channel/"+YOUTUBE_CHANNEL_ID_144+"/",
        thumbnail="http://mybuild.darkwebrepo.gq/infantil/oliviathepig.jpg",
        folder=True )	
											
    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]58. Peekaboo Kidz[/COLOR]",
        url="plugin://plugin.video.youtube/user/"+YOUTUBE_CHANNEL_ID_145+"/",
        thumbnail="http://mybuild.darkwebrepo.gq/infantil/peekaboo.jpg",
        folder=True )	
										
    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]59. Peppa Pig[/COLOR]",
        url="plugin://plugin.video.youtube/user/"+YOUTUBE_CHANNEL_ID_146+"/",
        thumbnail="http://mybuild.darkwebrepo.gq/infantil/peppa.jpg",
        folder=True )
										
    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]60. Peter Rabbit[/COLOR]",
        url="plugin://plugin.video.youtube/channel/"+YOUTUBE_CHANNEL_ID_147+"/",
        thumbnail="http://mybuild.darkwebrepo.gq/infantil/peterrabbit.jpg",
        folder=True )
										
    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]61. Pinkfong![/COLOR]",
        url="plugin://plugin.video.youtube/user/"+YOUTUBE_CHANNEL_ID_148+"/",
        thumbnail="http://mybuild.darkwebrepo.gq/infantil/pinkfong.jpg",
        folder=True )	
									
    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]62. PJ Masks[/COLOR]",
        url="plugin://plugin.video.youtube/channel/"+YOUTUBE_CHANNEL_ID_149+"/",
        thumbnail="http://mybuild.darkwebrepo.gq/infantil/pjmask.jpg",
        folder=True )
									
    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]63. Pocoyo[/COLOR]",
        url="plugin://plugin.video.youtube/user/"+YOUTUBE_CHANNEL_ID_150+"/",
        thumbnail="http://mybuild.darkwebrepo.gq/infantil/pocoyo.jpg",
        folder=True )
									
    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]64. Polly Pocket[/COLOR]",
        url="plugin://plugin.video.youtube/user/"+YOUTUBE_CHANNEL_ID_151+"/",
        thumbnail="http://mybuild.darkwebrepo.gq/infantil/polly.jpg",
        folder=True )
									
    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]65. Postman Pat[/COLOR]",
        url="plugin://plugin.video.youtube/channel/"+YOUTUBE_CHANNEL_ID_152+"/",
        thumbnail="http://mybuild.darkwebrepo.gq/infantil/postmanpat.jpg",
        folder=True )	
								
    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]66. Preschool Popstars[/COLOR]",
        url="plugin://plugin.video.youtube/user/"+YOUTUBE_CHANNEL_ID_153+"/",
        thumbnail="http://mybuild.darkwebrepo.gq/infantil/preschool.jpg",
        folder=True )
													
    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]67. Raa Raa the Noisy Lion[/COLOR]",
        url="plugin://plugin.video.youtube/channel/"+YOUTUBE_CHANNEL_ID_154+"/",
        thumbnail="http://mybuild.darkwebrepo.gq/infantil/raa-raa.jpg",
        folder=True )	
												
    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]68. Road Rangers[/COLOR]",
        url="plugin://plugin.video.youtube/channel/"+YOUTUBE_CHANNEL_ID_155+"/",
        thumbnail="http://mybuild.darkwebrepo.gq/infantil/roadranger.jpg",
        folder=True )
												
    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]69. Roary the Racing Car[/COLOR]",
        url="plugin://plugin.video.youtube/user/"+YOUTUBE_CHANNEL_ID_156+"/",
        thumbnail="http://mybuild.darkwebrepo.gq/infantil/roary.jpg",
        folder=True )	
											
    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]70. Rob The Robot[/COLOR]",
        url="plugin://plugin.video.youtube/channel/"+YOUTUBE_CHANNEL_ID_157+"/",
        thumbnail="http://mybuild.darkwebrepo.gq/infantil/robtherobot.jpg",
        folder=True )
												
    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]71. Robot Trains[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_158+"/",
        thumbnail="http://mybuild.darkwebrepo.gq/infantil/robottrainsa.jpg",
        folder=True )	
											
    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]72. Ruff-Ruff[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_159+"/",
        thumbnail="http://mybuild.darkwebrepo.gq/infantil/ruff-ruff.jpg",
        folder=True )	
										
    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]73. SciShow Kids[/COLOR]",
        url="plugin://plugin.video.youtube/user/"+YOUTUBE_CHANNEL_ID_160+"/",
        thumbnail="http://mybuild.darkwebrepo.gq/infantil/scishow.jpg",
        folder=True )	
									
    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]74. Sesame Street[/COLOR]",
        url="plugin://plugin.video.youtube/user/"+YOUTUBE_CHANNEL_ID_161+"/",
        thumbnail="http://mybuild.darkwebrepo.gq/infantil/sesamestreet.jpg",
        folder=True )
									
    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]75. Shopkins World[/COLOR]",
        url="plugin://plugin.video.youtube/channel/"+YOUTUBE_CHANNEL_ID_162+"/",
        thumbnail="http://mybuild.darkwebrepo.gq/infantil/shopkins.jpg",
        folder=True )
									
    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]76. Space Ranger Roger & Friends[/COLOR]",
        url="plugin://plugin.video.youtube/user/"+YOUTUBE_CHANNEL_ID_163+"/",
        thumbnail="http://mybuild.darkwebrepo.gq/infantil/spaceranger.jpg",
        folder=True )	
								
    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]77. StoryBots[/COLOR]",
        url="plugin://plugin.video.youtube/user/"+YOUTUBE_CHANNEL_ID_164+"/",
        thumbnail="http://mybuild.darkwebrepo.gq/infantil/storybots.jpg",
        folder=True )
											
    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]78. Super Why[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_165+"/",
        thumbnail="http://mybuild.darkwebrepo.gq/infantil/superwhy.jpg",
        folder=True )	
										
    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]79. Super Wings[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_166+"/",
        thumbnail="http://mybuild.darkwebrepo.gq/infantil/superwings.jpg",
        folder=True )
										
    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]80. Talking Tom and Friends[/COLOR]",
        url="plugin://plugin.video.youtube/user/"+YOUTUBE_CHANNEL_ID_167+"/",
        thumbnail="http://mybuild.darkwebrepo.gq/infantil/talkingtom.jpg",
        folder=True )	
									
    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]81. Teeter Taught Animation[/COLOR]",
        url="plugin://plugin.video.youtube/user/"+YOUTUBE_CHANNEL_ID_168+"/",
        thumbnail="http://mybuild.darkwebrepo.gq/infantil/teeter.jpg",
        folder=True )	
								
    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]82. The Airport Diary[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_169+"/",
        thumbnail="http://mybuild.darkwebrepo.gq/infantil/theairport.jpg",
        folder=True )	
							
    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]83. The Barkers[/COLOR]",
        url="plugin://plugin.video.youtube/user/"+YOUTUBE_CHANNEL_ID_170+"/",
        thumbnail="http://mybuild.darkwebrepo.gq/infantil/thebarkers.jpg",
        folder=True )
													
    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]84. The Children s Kingdom[/COLOR]",
        url="plugin://plugin.video.youtube/channel/"+YOUTUBE_CHANNEL_ID_171+"/",
        thumbnail="http://mybuild.darkwebrepo.gq/infantil/thechildrenkingdome.jpg",
        folder=True )
								
    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]85. The Gummy Bear Show[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_172+"/",
        thumbnail="http://mybuild.darkwebrepo.gq/infantil/gummybear.jpg",
        folder=True )	
							
    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]86. The Holy Tales: Bible[/COLOR]",
        url="plugin://plugin.video.youtube/user/"+YOUTUBE_CHANNEL_ID_173+"/",
        thumbnail="http://mybuild.darkwebrepo.gq/infantil/theholytales.jpg",
        folder=True )	
						
    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]87. The Fixies[/COLOR]",
        url="plugin://plugin.video.youtube/channel/"+YOUTUBE_CHANNEL_ID_174+"/",
        thumbnail="http://mybuild.darkwebrepo.gq/infantil/thefixes.jpg",
        folder=True )	
										
    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]88. Thomas And Friends[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_175+"/",
        thumbnail="http://mybuild.darkwebrepo.gq/infantil/thomas&friends.jpg",
        folder=True )
										
    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]89. Tinyschool[/COLOR]",
        url="plugin://plugin.video.youtube/user/"+YOUTUBE_CHANNEL_ID_176+"/",
        thumbnail="http://mybuild.darkwebrepo.gq/infantil/tinyschool.jpg",
        folder=True )
												
    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]90. Tigger & Pooh[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_177+"/",
        thumbnail="http://mybuild.darkwebrepo.gq/infantil/tigger&pooh.jpg",
        folder=True )	
											
    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]91. Toddler Fun Learning[/COLOR]",
        url="plugin://plugin.video.youtube/user/"+YOUTUBE_CHANNEL_ID_178+"/",
        thumbnail="http://mybuild.darkwebrepo.gq/infantil/toddlerfunlearning.jpg",
        folder=True )	
										
    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]92. Toobys[/COLOR]",
        url="plugin://plugin.video.youtube/user/"+YOUTUBE_CHANNEL_ID_179+"/",
        thumbnail="http://mybuild.darkwebrepo.gq/infantil/toobys.jpg",
        folder=True )	
									
    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]93. Tractor Tom[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_180+"/",
        thumbnail="http://mybuild.darkwebrepo.gq/infantil/tractortom.jpg",
        folder=True )
									
    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]94. Trains-The Animated Series[/COLOR]",
        url="plugin://plugin.video.youtube/channel/"+YOUTUBE_CHANNEL_ID_181+"/",
        thumbnail="http://mybuild.darkwebrepo.gq/infantil/trains.jpg",
        folder=True )
										
    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]95. Treehouse Direct[/COLOR]",
        url="plugin://plugin.video.youtube/user/"+YOUTUBE_CHANNEL_ID_182+"/",
        thumbnail="http://mybuild.darkwebrepo.gq/infantil/treehouse.jpg",
        folder=True )	
									
    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]96. Umi Uzi[/COLOR]",
        url="plugin://plugin.video.youtube/channel/"+YOUTUBE_CHANNEL_ID_183+"/",
        thumbnail="http://mybuild.darkwebrepo.gq/infantil/umiuzi.jpg",
        folder=True )
									
    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]97. Veggie Tales[/COLOR]",
        url="plugin://plugin.video.youtube/user/"+YOUTUBE_CHANNEL_ID_184+"/",
        thumbnail="http://mybuild.darkwebrepo.gq/infantil/veggietale.jpg",
        folder=True )	
								
    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]98. Videogyan 3D Rhymes[/COLOR]",
        url="plugin://plugin.video.youtube/user/"+YOUTUBE_CHANNEL_ID_185+"/",
        thumbnail="http://mybuild.darkwebrepo.gq/infantil/videogyan.jpg",
        folder=True )

								
    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]99. Vroomiz[/COLOR]",
        url="plugin://plugin.video.youtube/channel/"+YOUTUBE_CHANNEL_ID_186+"/",
        thumbnail="http://mybuild.darkwebrepo.gq/infantil/vroomiz.jpg",
        folder=True )	
							
    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]100. Wild Kratts[/COLOR]",
        url="plugin://plugin.video.youtube/channel/"+YOUTUBE_CHANNEL_ID_187+"/",
        thumbnail="http://mybuild.darkwebrepo.gq/infantil/wildkratts1.jpg",
        folder=True )
									
    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]101. Word World TV[/COLOR]",
        url="plugin://plugin.video.youtube/channel/"+YOUTUBE_CHANNEL_ID_188+"/",
        thumbnail="http://mybuild.darkwebrepo.gq/infantil/wordworld.jpg",
        folder=True )
									
    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]102. Zig & Sharko[/COLOR]",
        url="plugin://plugin.video.youtube/channel/"+YOUTUBE_CHANNEL_ID_189+"/",
        thumbnail="http://mybuild.darkwebrepo.gq/infantil/zig&shark.jpg",
        folder=True )	
								
    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]103. ZOU[/COLOR]",
        url="plugin://plugin.video.youtube/user/"+YOUTUBE_CHANNEL_ID_190+"/",
        thumbnail="http://mybuild.darkwebrepo.gq/infantil/zou.jpg",
        folder=True )
									
    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]104. 10 Friends of Rabbit`s[/COLOR]",
        url="plugin://plugin.video.youtube/channel/"+YOUTUBE_CHANNEL_ID_191+"/",
        thumbnail="http://mybuild.darkwebrepo.gq/infantil/10friends.jpg",
        folder=True )
										
    plugintools.add_item( 
        #action="", 
        title="[COLOR yellow]105. 64 Zoo Lane[/COLOR]",
        url="plugin://plugin.video.youtube/channel/"+YOUTUBE_CHANNEL_ID_192+"/",
        thumbnail="http://mybuild.darkwebrepo.gq/infantil/zoolane.jpg",
        folder=True )	
run()
